#include<stdio.h>
int main()
{
	int year,month,day;
	year=2015;
	month=10;
	day=21;
	int a=1000;
	
}
