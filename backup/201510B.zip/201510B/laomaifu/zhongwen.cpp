#include<iostream>
using namespace std;
int main(int argc,char *argv[])
{
	char *zhongwen="中文";
	cout<<zhongwen<<endl;
	return 0;
}
