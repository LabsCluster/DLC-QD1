#include "stdio.h"
#include "conio.h"
main()
{
  printf("Hello C-world!\n");
    printf(" ****\n");
	  printf(" *\n");
	    printf(" * \n");
		  printf(" ****\n");
		    getch();
			}
