#include<stdio.h>
int main()
{
  int a,b,c,sum
  scanf("%d%d%d&a&b&c)
  scanf(sum=a+b+c)
  printf(%d%d%d%d,a,b,c)
  return 0
 }
