#include<stdio.h>
#include<math.h>
int main()
{
	scanf("%d,%d");
	printf("1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2\n");
	printf("2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1");
	return 0;
}

