#include<stdio.h>
int main()
{
	double j,h;
	scanf("%lf",&j);
	h=3.1415*j/180;
	printf("%lf",h);
	return 0;
}

