#include<stdio.h>
int main()
{
	int n;
	for(n=10;n<=100;n++)
	printf("%d\n",n);
	return 0;
}

