#include<stdio.h>
int main()
{
	double a,b,pi;
	pi=3.141592653579;
	scanf("%lf",&a);
	b=a*(pi/180);
	printf("%lf",b);
	return 0;
}
