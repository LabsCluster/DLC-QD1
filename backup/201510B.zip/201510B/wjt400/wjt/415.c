#include<stdio.h>
int main()
{
	int a[20];
	int i;
	for(i=0;i<20;i++)
	{
		a[i]=1;
		printf("%d",a[i]);
	}	
	return 0;
}



