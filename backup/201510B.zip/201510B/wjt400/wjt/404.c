#include<stdio.h>
int main()
{
     char c1,c2,c3,c4,c5,c6,c7,c8,c9,c10;
	 scanf("%c%c%c%c%c",&c1,&c2,&c3,&c4,&c5);
	 c6=c1+32;
	 c7=c2+32;
	 c8=c3+32;
	 c9=c4+32;
	 c10=c5+32;
	 printf("%c%c%c%c%c\n",c6,c7,c8,c9,c10);
	 return 0;
}








