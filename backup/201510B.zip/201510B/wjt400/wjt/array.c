int main()
{
	int a[2];
	a[0]=1;
	a[1]=2;sh: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C
	ct 24 13:40 - 15:57  (02:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/3        117.112.62.32    Sat Oct 24 11:57 - 13:35  (01:38)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/2        117.112.62.31    Sat Oct 24 11:25 - 14:02  (02:37)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        117.136.38.56    Sat Oct 24 11:23 - 11:24  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/3        117.136.38.56    Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ songyy   pts/2        114.113.123.163  Sat Oct 24 11:22 - 11:23  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.31    Sat Oct 24 11:19 - 13:31  (02:12)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/0        117.112.62.51    Sat Oct 24 10:27 - 13:10  (02:43)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ laomaifu pts/2        117.112.62.51    Sat Oct 24 09:52 - 09:52  (00:00)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ dgideas  pts/2        114.248.225.44   Sat Oct 24 09:21 - 09:38  (00:16)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ sun      pts/1        117.112.62.51    Sat Oct 24 09:13 - 10:26  (01:13)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ chenjibo pts/0        125.34.56.13     Sat Oct 24 09:00 - 10:01  (01:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ egon     pts/1        117.112.62.51    Sat Oct 24 00:24 - 00:25  (00:01)
	-bash: syntax error near unexpected token `('
	[wjt400@iZ28z2o8xtwZ wjt]$ ^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^C
	[wjt400@iZ28z2o8xtwZ wjt]$ vim 414.c
	[wjt400@iZ28z2o8xtwZ wjt]$ make 414
	cc     414.c   -o 414
	[wjt400@iZ28z2o8xtwZ wjt]$ ./414
	^[^C

	return 0;
}
