#include<stdio.h>
#include<math.h>
int main()
{
	long n,ji,s;
	scanf("%d",&n);
	ji=n*n*n;
	printf("%d\n",ji);
	s=n*n;
	printf("%d\n",s);
	return 0;
}
