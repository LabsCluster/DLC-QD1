#include<stdio.h>
int main()
{
	int n;
	n=10;
	while(n<=100)
	{
	printf("%d\n",n);
	n++;
		}
    printf("Perfect!\n");
	return 0;
}
