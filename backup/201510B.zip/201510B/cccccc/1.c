#include<stdio.h>
int main()
{
	printf("VERY GOOD\n");
    return 0;
}
