#include<stdio.h>
int main()
{
		struct Student
		{
				int score;
				char name[20];
		} student_1, student_2;
		
		scanf("%d%s", &sutdent_1.score, &student_1.name);
		scanf("%d%s", &student_2.score. &ssudent_2.name);

		if(student_1.score > student_2.score)
		{
				printf("%d, %s", student_1.score, student_1.name);
		}
		else if(student_1.score < student_2.score)
		{
				printf("%d, %s", student_2.score, student_2.name);
		}
		else
		{

				printf("%d, %s", student_1.score, student_1.name);
		}
