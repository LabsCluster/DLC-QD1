#include<stdio.h>
int main()
{
		struct Student
		{
				int num;
				char name[20];
				char sex;
				char addr[20];
		} student_a = {10,"shabi",'A',"BEIJING"};

		printf("%d, %s, %s, %s\n", student_a.num, student_a.name, student_a.sex, student_a.addr);

		return 0;
}
