#include<iostream>
int main()
{
	using namespace std;
	cout<<"hello world!!";
	cout<<endl;
	cout<<"hello"<<endl
}
