#include<stdio.h>
int main()
{
	double a=1.0, sum=0.0;
	while(sum <= 5.0)
	{
		sum = sum+1.0/a;
		a++;
	}
	printf("%lf\n", a-1);
	return 0;
}
