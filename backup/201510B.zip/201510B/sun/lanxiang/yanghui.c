#include<stdio.h>
int main()
{
	int a[8][8];
	int i, j;

	for (i=0; i<8; i++)
	{
		a[i][0]=1;
		a[i][i]=1;
	}
	for (j=2; j<=7; j++)
	{
		for (i=1; i<j; i++)
		{
			a[j][i]=a[j-1][i]+a[j-1][i-1];
		}
	}

	for (j=0; j<=7; j++)
	{
		for (i=0; i<=j; i++)
		{
			if(i==j)
			{
				printf("%d\n",a[j][i]);
			}
			else
			{
				printf("%d ", a[j][i]);	
			}
		}
	}
	return 0;
}
