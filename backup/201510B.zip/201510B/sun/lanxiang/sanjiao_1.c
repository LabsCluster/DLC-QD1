#include<stdio.h>
int main()
{
	long int a, i, a1, a2, a3, a4_1, a5, a6, a7;
	long int b1, b2, b3, b4, b5, b6, b7;
	for (i=9999999;i>=1000000 ; i--)
	{
		a1=i%10;
		a2=i%100;
		a3=i%1000;
		a4_1=i%10000;
		a5=i%100000;
		a6=i%1000000;
		a7=i%10000000;
		/*a1=i/1000000;
		a2=i/100000%10;
		a3=i/10000%10;
		a4=i/1000%10;
		a5=i/100%10;
		a6=i/10%10;
		a7=i%10;*/
		//printf("%d %d %d %d %d %d %d\n",a1,a2,a3,a4,a5,a6,a7);
		//break;
		/*b1=i;
		b2=b1-a1*1000000;
		b3=b2-a2*100000;
		b4=b3-a3*10000;
		b5=b4-a4*1000;
		b6=b5-a5*100;
		b7=b6-a6*10;*/


		int a4;
		a4=i/1000%10;
		a=a4+a4*10+a4*100+a4*1000+a4*10000+a4*100000+a4*1000000;
		if (a==a1+a2+a3+a4_1+a5+a6+a7)
		{
			printf("%ld\n", i);
			break;
		}
	}

	return 0;
}
