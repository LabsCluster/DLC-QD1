#include<stdio.h>
#include<math.h>
int main()
{
	int k, i, j;
	int a1, a2, a3, a4, a5, a;
	for (j=99999; j>=10000; j--)
	{
		k=sqrt(j);
		for (i=2; i<j; i++)
		{
			if (0==j%i)
			{
				break;
			}
			if (i>=k+1)
			{
				a5=j%10;
				a4=j/10%10;
				a3=j/100%10;
				a2=j/1000%10;
				a1=j/10000%10;

			}
		}
	}
	return 0;
}
