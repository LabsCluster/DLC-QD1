#include<stdio.h>
int main()
{
	int a, b, sum=0, i, t;
	scanf("%d%d",&a,&b);
	for (i=1; i<=b; i++)
	{
		t=a%10;
		sum=sum+t*t;
		a=a/10;
	}
	printf("%d \n",sum);
	return 0;
}
