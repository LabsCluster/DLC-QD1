#include<stdio.h>
int main()
{
	int fun(int n);
	int a, b, i;
	scanf("%d%d", &a, &b);
	for (i=1; i<=b; i++)
	{
	a=fun(a);}
	printf("%d\n", a);
	return 0;
}

int fun(int n)
{
	int c, sum=0;
	while(n)
	{
	c=n%10;
	sum=sum+c*c;
	n=n/10;
	}

	return sum;
}
