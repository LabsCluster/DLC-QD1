#include<stdio.h>
int main()
{
	double a, ji=1, i;
	for (i=1; i<=a)

}
