#include<stdio.h>
#include<math.h>

long int sushu(long int a);
long int paixu(long int b);
long int main()
{
	long int j, i, k;
	long int a1, a2, a3, a4, a5, a, t;

	for (j=999999; j>=100000; j--)
	{
		t=sushu(j);
		if(t!=0)
		t=paixu(t);
		else
		{
			continue;
		}
		
		t=sushu(t);
		if (t!=0)
		t=paixu(t);
		else
		{
		continue;
		}

		t=sushu(t);
		if (t!=0)
		t=paixu(t);
		else
		{
			continue;
		}

		t=sushu(t);
		if (t!=0)
		t=paixu(t);
		else
		{
			continue;
		}
		
		if (t!=0)
		t=sushu(t);
		else
		{
			continue;
		}
		if(t!=0)
		printf("%ld\n",t);
	}

	return 0;
}

long int sushu(long int a)
{
	long int i;
	long int flag=1;
	for (i=0; i<=sqrt(a); i++)
	{
		if (0==a/i)
		{
			flag=0;
			break;
		}
	}
	return flag=i;
}

long int paixu(long int a_2)
{
	long int a1, a2;
	a1=a_2/10;
	a2=a_2%10;
	return a2*10000+a1;
}
