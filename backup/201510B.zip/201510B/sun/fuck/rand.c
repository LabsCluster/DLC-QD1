#include<stdio.h>
#include<stdlib.h>
int main()
{
	int j,i;
	for(i=0 ;i<=10;i++ )
	{
		j=rand();
		printf("%d\n",rand());
	}

	return 0;
}
