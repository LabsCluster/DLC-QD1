#include<stdio.h>
int main()
{
int a,y;
printf("请输入一个数值a。\n");
scanf("%d",&a);
if(a>0)
y=1;
else
if(a=0)
y=0;
else
y=-1;
printf("%d",y);
return 0;
}

