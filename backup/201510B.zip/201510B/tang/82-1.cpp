#include<stdio.h>
#include<math.h>

int main()
{
	double p,n;
	scanf("%lf",&n);
	p=pow(1+0.09,n);
	printf("%f",p);
	return 0;
}
