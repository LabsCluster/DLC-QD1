#include<stdio.h>
int main()

{
	printf("sgsgg");
	return 0;
}
