#include<stdio.h>
int main()
{float a,b,c;
c=3.14;
printf("请输入一个角度值：");
scanf("%f",&a);
b=c/180*a;
printf("b=%f\n",b);
return 0;}
