#include<stdio.h>
int main()
{int i;
i=9;
while(i<100)
printf("%d\n",++i);
return 0;}
