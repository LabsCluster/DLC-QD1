#include<stdio.h>
int main()
{int month;
for(month=0;month<=11;month++)
month[]={31,28,31,30,31,30,31,31,30,31,30,31};
printf("%d",month);
return 0;}
