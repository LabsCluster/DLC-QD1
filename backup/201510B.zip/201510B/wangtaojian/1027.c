#include<stdio.h>
int main()
{
int i;
float a[5]={1.1,2.1,3.4,4.3,5.2};
for(i=0;i<5;i++)
printf("%f\n",a[i]);
return 0;}
