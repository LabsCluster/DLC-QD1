#include<stdio.h>
int main()
{char c1,c2;
printf("请输入一个大写字母：");
scanf("%c",&c1);
c2=c1+32;
printf("这个字母小写是：%c\n",c2);
return 0;
}
