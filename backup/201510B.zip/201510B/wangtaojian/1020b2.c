#include<stdio.h>
int main()
{int i;
for(i=10;i<=100;i++)
printf("%d\n",i);
return 0;
}
