#include<stdio.h>
int main()
{int i;
i=2;
for
