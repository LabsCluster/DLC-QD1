#include<stdio.h>
int main()
{
	printf("qqqqqqq\n");
	return 0;

