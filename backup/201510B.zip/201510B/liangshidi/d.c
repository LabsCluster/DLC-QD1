#include<stdio.h>
int main()
{
	printf("bjhku\n");
	return 0;
}
